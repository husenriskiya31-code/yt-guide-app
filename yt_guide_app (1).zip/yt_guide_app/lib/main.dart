import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'content.dart';

const tel = '0948702702'; // ቴሌብር ቁጥር
const price = 199;
const bg = Color(0xFF0F0F1A), card = Color(0xFF1B1B2E), gold = Color(0xFFFFB800), red = Color(0xFFFF3B3B);

void main() => runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ዩቲዩብ አልጎሪዝም',
      theme: ThemeData(useMaterial3: true, brightness: Brightness.dark, scaffoldBackgroundColor: bg,
          colorScheme: const ColorScheme.dark(primary: red, secondary: gold)),
      home: const Home(),
    ));

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool paid = false;
  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) => setState(() => paid = p.getBool('paid') ?? false));
  }

  void open(int i) {
    if (i > 0 && !paid) return showPay();
    Navigator.push(context, MaterialPageRoute(builder: (_) => Reader(i, paid, showPay)));
  }

  void showPay() => showModalBottomSheet(
        context: context, isScrollControlled: true, backgroundColor: card,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        builder: (_) => PaySheet(onPaid: () async {
          (await SharedPreferences.getInstance()).setBool('paid', true);
          if (mounted) setState(() => paid = true);
        }),
      );

  @override
  Widget build(BuildContext c) => Scaffold(
        body: ListView(padding: EdgeInsets.zero, children: [
          Container(
            padding: const EdgeInsets.fromLTRB(22, 60, 22, 26),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [red, Color(0xFF7B2FF7)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(34))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('▶ የዩቲዩብ አልጎሪዝም', style: TextStyle(fontSize: 12)),
              const SizedBox(height: 6),
              const Text('ዩቲዩብ ለምን ሌሎችን ያሳያል — አንተን ግን አይደለም?',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, height: 1.35)),
              const SizedBox(height: 8),
              const Text('የ MrBeast፣ Derral Eves እና Jon Youshaei ሚስጥሮች በአማርኛ — 8 ክፍሎች።', style: TextStyle(fontSize: 14)),
              const SizedBox(height: 16),
              paid
                  ? const Chip(label: Text('✔ ሙሉ መዳረሻ አለዎት'))
                  : FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black,
                          minimumSize: const Size.fromHeight(50)),
                      onPressed: showPay, child: Text('🔓 ሁሉንም ክፈት — $price ብር')),
            ]),
          ),
          const Padding(padding: EdgeInsets.fromLTRB(18, 22, 18, 4), child: Text('ጉዞህ', style: TextStyle(color: gold, fontWeight: FontWeight.bold))),
          for (int i = 0; i < chapters.length; i++)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => open(i),
                child: Ink(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(20)),
                  child: Row(children: [
                    CircleAvatar(radius: 22, backgroundColor: red, child: Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.white))),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(i == 0 ? 'ክፍል 1 • ነጻ ጀምር' : 'ክፍል ${i + 1}',
                          style: TextStyle(fontSize: 11, color: i == 0 ? Colors.greenAccent : gold, fontWeight: FontWeight.bold)),
                      Text(chapters[i][0], style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, height: 1.4)),
                      Text(chapters[i][1], style: const TextStyle(fontSize: 12, color: Colors.white60)),
                    ])),
                    Icon(i > 0 && !paid ? Icons.lock : Icons.chevron_right, color: Colors.white54),
                  ]),
                ),
              ),
            ),
          const SizedBox(height: 40),
        ]),
      );
}

class Reader extends StatefulWidget {
  final int i; final bool paid; final VoidCallback pay;
  const Reader(this.i, this.paid, this.pay, {super.key});
  @override
  State<Reader> createState() => _ReaderState();
}

class _ReaderState extends State<Reader> {
  final sc = ScrollController();
  double p = 0;
  @override
  void initState() {
    super.initState();
    sc.addListener(() {
      if (sc.position.maxScrollExtent > 0) setState(() => p = sc.offset / sc.position.maxScrollExtent);
    });
  }

  Widget block(List<String> b) {
    switch (b[0]) {
      case 'h':
        return Padding(padding: const EdgeInsets.only(top: 28, bottom: 6), child: Text(b[1], style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)));
      case 'q':
        return Container(margin: const EdgeInsets.symmetric(vertical: 12), padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: red.withOpacity(.13), border: const Border(left: BorderSide(color: red, width: 4)), borderRadius: BorderRadius.circular(14)),
            child: Text(b[1], style: const TextStyle(fontWeight: FontWeight.bold, height: 1.7)));
      case 'box':
        return Container(margin: const EdgeInsets.symmetric(vertical: 8), padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16)), child: Text(b[1], style: const TextStyle(height: 1.8, fontSize: 14)));
      case 'acc':
        return Container(margin: const EdgeInsets.symmetric(vertical: 4),
            decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(14)),
            child: ExpansionTile(shape: const Border(), title: Text(b[1], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                children: [Align(alignment: Alignment.centerLeft, child: Text(b[2], style: const TextStyle(color: Colors.white70, height: 1.7)))]));
      case 'tl':
        return Container(margin: const EdgeInsets.only(left: 6, top: 8), padding: const EdgeInsets.only(left: 14),
            decoration: const BoxDecoration(border: Border(left: BorderSide(color: red, width: 3))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              for (final t in b[1].split('|')) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(t, style: const TextStyle(height: 1.7, fontSize: 14)))]));
      default:
        return Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text(b[1], style: const TextStyle(fontSize: 16, height: 1.8)));
    }
  }

  @override
  Widget build(BuildContext c) {
    final i = widget.i;
    return Scaffold(
      appBar: AppBar(backgroundColor: bg, title: LinearProgressIndicator(value: p, color: gold, backgroundColor: Colors.white12, minHeight: 4, borderRadius: BorderRadius.circular(4))),
      body: ListView(controller: sc, padding: const EdgeInsets.fromLTRB(20, 0, 20, 60), children: [
        Text('${i + 1}', style: const TextStyle(fontSize: 70, fontWeight: FontWeight.w900, color: red, height: 1)),
        Text(i == 0 ? 'ክፍል 1 • ነጻ' : 'ክፍል ${i + 1}', style: const TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 12)),
        Text(chapters[i][0], style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900, height: 1.35)),
        if (i == 0) ...ch1.map(block) else const Padding(padding: EdgeInsets.only(top: 20), child: Text('📖 የዚህ ክፍል ሙሉ ጽሑፍ በቅርቡ ይታከላል።')),
        if (i == 0)
          Container(margin: const EdgeInsets.only(top: 28), padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(gradient: const LinearGradient(colors: [red, Color(0xFF7B2FF7)]), borderRadius: BorderRadius.circular(22)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('ቀጣይ ክፍል 2 👇', style: TextStyle(fontWeight: FontWeight.bold)),
                const Text('7ቱ ገዳይ ስህተቶች — አብዛኞቹ ቻናሎች የሚሞቱበት። አንተ ስንቱን እየሰራህ ነው?'),
                const SizedBox(height: 12),
                FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black, minimumSize: const Size.fromHeight(48)),
                    onPressed: () {
                      Navigator.pop(context);
                      if (!widget.paid) widget.pay();
                    },
                    child: Text(widget.paid ? 'ወደ ዝርዝሩ ተመለስ' : '🔓 ክፍል 2ን ክፈት')),
              ])),
      ]),
    );
  }
}

class PaySheet extends StatefulWidget {
  final Future<void> Function() onPaid;
  const PaySheet({super.key, required this.onPaid});
  @override
  State<PaySheet> createState() => _PaySheetState();
}

class _PaySheetState extends State<PaySheet> {
  final tx = TextEditingController(), code = TextEditingController();
  String msg = ''; bool ok = false;
  void say(String m, [bool g = false]) => setState(() { msg = m; ok = g; });

  Widget step(String n, Widget w) => Padding(padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        CircleAvatar(radius: 13, backgroundColor: red, child: Text(n, style: const TextStyle(fontSize: 13, color: Colors.white))),
        const SizedBox(width: 10), Expanded(child: w)]));

  @override
  Widget build(BuildContext c) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(c).viewInsets.bottom + 24),
        child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('🔓 ሁሉንም 8 ክፍሎች ክፈት', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const Text('$price ብር', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: gold)),
          step('1', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('በቴሌብር $price ብር ወደዚህ ቁጥር ላኩ፦'),
            Container(margin: const EdgeInsets.only(top: 6), padding: const EdgeInsets.fromLTRB(14, 4, 6, 4),
              decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14)),
              child: Row(children: [
                const Text(tel, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), const Spacer(),
                TextButton(onPressed: () { Clipboard.setData(const ClipboardData(text: tel)); say('ቁጥሩ ተቀድቷል', true); }, child: const Text('ቅዳ'))]))])),
          step('2', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('የቴሌብር ደረሰኝ ቁጥር (Transaction ID)፦'),
            TextField(controller: tx, decoration: const InputDecoration(hintText: 'ለምሳሌ፦ CKL1A2B3C4')),
            const SizedBox(height: 8),
            FilledButton(onPressed: () {
              if (tx.text.trim().isEmpty) return say('የደረሰኝ ቁጥር ያስገቡ');
              launchUrl(Uri.parse('sms:$tel?body=${Uri.encodeComponent('YT Guide ክፍያ $price ብር። Telebirr ID: ${tx.text.trim()}')}'));
            }, child: const Text('📩 ደረሰኙን ላክ')),
            const Text('ክፍያው ተረጋግጦ የመክፈቻ ኮድ ይላክልዎታል።', style: TextStyle(fontSize: 11, color: Colors.white54))])),
          step('3', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('የመክፈቻ ኮድ፦'),
            TextField(controller: code, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(hintText: 'YTG-0000')),
            const SizedBox(height: 8),
            FilledButton(onPressed: () async {
              final m = RegExp(r'^YTG-(\d{4})$').firstMatch(code.text.trim().toUpperCase());
              if (m != null && int.parse(m.group(1)!) % 97 == 13) {
                await widget.onPaid(); say('✔ ተከፍቷል! እንኳን ደህና መጡ', true);
                await Future.delayed(const Duration(milliseconds: 800));
                if (mounted) Navigator.pop(context);
              } else { say('ኮዱ ትክክል አይደለም'); }
            }, child: const Text('ክፈት')),
            Text(msg, style: TextStyle(color: ok ? Colors.greenAccent : Colors.redAccent, fontSize: 13))])),
        ])),
      );
}
